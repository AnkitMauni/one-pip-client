import { Component } from '@angular/core';

@Component({
  selector: 'app-real',
  standalone: true,
  imports: [],
  templateUrl: './real.component.html',
  styleUrls: ['./real.component.scss']
})
export class RealComponent {

}
