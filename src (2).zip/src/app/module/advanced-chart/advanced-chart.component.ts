
import { Component, Input, OnInit } from '@angular/core';
import {
  BarStyles,
  CONTAINER_ID,
  IntervalTypes,
  ITradingViewWidget,
  Themes
} from 'angular-tradingview-widget';
import { TradingviewWidgetModule } from 'angular-tradingview-widget';
interface IExtendedTradingViewWidget extends ITradingViewWidget {
  datafeed?: {
    OHLC?: any; // Replace with your actual OHLC data structure
    datafeedReadyCallback?: () => void;
    // Add any other datafeed properties as needed
  };
}
declare const TradingView: any;

@Component({
  selector: 'app-advanced-chart',
  templateUrl: './advanced-chart.component.html',
  styleUrls: ['./advanced-chart.component.scss'],
  standalone: true,
  imports:[TradingviewWidgetModule]
})
export class AdvancedChartComponent implements OnInit {
 symbolData: string = 'NASDAQ:AAPL';
  chartData: any=[];
  private _widgetConfig!: ITradingViewWidget;
  _defaultConfig:any=[]
  style: {} = {};
  containerId = CONTAINER_ID;
  ITradingViewWidget: {
    symbol: string; allow_symbol_change: boolean; autosize: boolean; enable_publishing: boolean; height: number; hideideas: boolean; hide_legend: boolean; hide_side_toolbar: boolean; hide_top_toolbar: boolean; interval: IntervalTypes; locale: string; save_image: boolean; show_popup_button: boolean; style: BarStyles; theme: Themes; timezone: string // Add any other datafeed properties as needed
      ; toolbar_bg: string; widgetType: string; width: number; withdateranges: boolean; datafeed: { OHLC: any; };
  };
  

  @Input('widgetConfig') set widgetConfig (value: ITradingViewWidget) {
      this._widgetConfig = value;
      this.cleanWidget();
      this.initWidget();
   }
   get widgetConfig (): ITradingViewWidget {
    return this._widgetConfig || this._defaultConfig;
  }

  constructor() {
      this._defaultConfig= this.ITradingViewWidget = {
      symbol: 'NASDAQ:AAPL',
      allow_symbol_change: true,
      autosize: false,
      enable_publishing: false,
      height: 610,
      hideideas: true,
      hide_legend: false,
      hide_side_toolbar: true,
      hide_top_toolbar: false,
      interval: IntervalTypes.D,
      locale: 'en',
      save_image: true,
      show_popup_button: false,
      style: BarStyles.CANDLES,
      theme: Themes.LIGHT,
      timezone: 'Etc/UTC',
      toolbar_bg: '#F1F3F6',
      widgetType: 'widget',
      width: 980,
      withdateranges: false,
      datafeed: {
        OHLC: this.chartData
      }
    };
  }

  ngOnInit(): void {}
cleanWidget () {
    if (!this.canUseDOM()) return;
    const container = this.getContainer();
    if(container) {
      container.innerHTML = '';
    }
  };
    getContainer () {
    return document.getElementById(this.containerId);
  }
    canUseDOM () {
    return typeof window !== 'undefined' &&
    window.document &&
    window.document.createElement
  }

   initWidget() {
    /* global TradingView */
    if (typeof TradingView === 'undefined' || !this.getContainer()) return;
  
    const { widgetType, ...widgetConfig } = this.widgetConfig;
    const config = { ...widgetConfig, container_id: this.containerId };
  
    if (config.autosize) {
      delete config.width;
      delete config.height;
    }
  
    if (config.popup_width && typeof config.popup_width === 'number') {
      config.popup_width = config.popup_width.toString();
    }
  
    if (config.popup_height && typeof config.popup_height === 'number') {
      config.popup_height = config.popup_height.toString();
    }
  
    if (config.autosize) {
      this.style = {
        width: '100%',
        height: '100%',
      };
    }
  
    // Check if TradingView is ready
    const checkTradingViewReady = () => {
      if (typeof TradingView !== 'undefined' && typeof TradingView[widgetType] === 'function') {
        // TradingView is ready, create the widget
        const widget = new TradingView[widgetType](config);
  
        // Attach onready callback
        widget.onready(() => {
          // Log data to console
          console.log('Chart Data:', this.chartData);
  
          // Set the OHLC data when the chart is ready
          widget.chart().setSymbol(this.symbolData, this.chartData);
        });
      } else {
        // TradingView is not yet ready, check again after a short delay
        setTimeout(checkTradingViewReady, 100);
      }
    };
  
    checkTradingViewReady();
  }
}

